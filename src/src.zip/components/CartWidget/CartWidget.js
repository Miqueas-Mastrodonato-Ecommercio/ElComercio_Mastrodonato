import logo from '../../components/Images/carrito.png';

const CartWidget = ({props} ) => {
    return(
        <div>
         <img src={logo} className="App-logoNav" alt="logo" /> 
        </div>
    )
}

export default CartWidget;
