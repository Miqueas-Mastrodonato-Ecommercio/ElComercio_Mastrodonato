
const mockDetail = [
    {
        id: 1,
        name: 'Vino Rose Portillo Malbec',
        description: 'Vino Malbec portada especial San Antonio',
        price: '$900',
        type: 'Rosa',
        content:'750cc',
        image:'https://cepadevinos.com/wp-content/uploads/2018/10/portillo-rose-malbec.png',
        stock:'10',
    },
];

export default mockDetail;
