import logo from '../../components/Images/entrada.png';

const ImgBoleto = ({props} ) => {
    return(
        <div>
         <img src={logo} className="img-boleto" alt="logo" /> 
        </div>
    )
}

export default ImgBoleto;